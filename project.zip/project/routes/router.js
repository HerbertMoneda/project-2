const express = require('express');
const router = express.Router();

router.get('/Home', (req, res) => {
    res.render('home', { title: "Home"});
});

router.get('/AboutUs', (req, res) => {
    res.render('aboutUs', { title: "About Us"});
});

router.get('/Portfolio', (req, res) => {
    res.render('portfolio', { title: "Portfolio"});
});

router.get('/SignIn', (req, res) => {
    res.render('signin', { title: "Sign in"});
});

router.get('/BookingForm', (req, res) => {
    res.render('bookingform', { title: "Book Now"});
});


 


    

module.exports = router;