//imports
const express = require('express');
const methodOverride = require('method-override');
const mongoose = require('mongoose');
// const dotEnv = require('dotenv');
const app = express();


//roouter
const router = require('./routes/router');



//Static files
app.use(express.static('public'));



//middleware
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(express.json());

//set view
app.set('views', './views');
app.set('view engine', 'ejs');

//routes
app.use('/', router);




//Environment config
// dotEnv.config();


//Server connection
// mongoose.connect(process.env.DB_CONNECT, () => console.log("Database is running"));

const port = 8080;
app.listen(port, () => console.log(`Server is running in ${port}`));